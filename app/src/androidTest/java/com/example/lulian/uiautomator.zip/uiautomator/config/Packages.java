package com.example.lulian.uiautomator.config;

/**
 * Created by lulian on 2017/6/17.
 */

public class Packages {
    public static final String OSCHINA_PACKAGE_NAME = "net.oschina.app";
    public static final String OSCHINA_LAUNCH_ACTIVITY_NAME = "net.oschina.app.LaunchActivity";
}
