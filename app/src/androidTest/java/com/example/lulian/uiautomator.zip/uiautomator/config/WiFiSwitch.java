package com.example.lulian.uiautomator.config;

/**
 * Created by lulian on 2017/6/18.
 */

public class WiFiSwitch {
    public static final boolean WIFI_ON = true;
    public static final boolean WIFI_OFF = false;

}
